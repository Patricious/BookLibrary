﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using LibraryWebApI.Models;

namespace LibraryWebApI.Controllers
{
    public class BOOKsController : Controller
    {
        private LibraryEntities3 db = new LibraryEntities3();

        // GET: BOOKs
        public ResponseMapper Index()
        {
            var res = new ResponseMapper();
            res.code = "00";
            res.message = "success";
            res.data = db.BOOKs.ToList();
            return res;
        }

        // GET: BOOKs/Details/5
        public ResponseMapper Details(string id)
        {
            List<BOOK> bOOKs = new List<BOOK>();
            var res = new ResponseMapper();
            if (id == null)
            {
                res.code = "06";
                res.message = HttpStatusCode.BadRequest.ToString();
                return res;
            }

            BOOK bOOK = db.BOOKs.Find(id);
            if (bOOK == null)
            {
                res.code = "06";
                res.message = "Book not found";
                return res;
            }
            bOOKs.Add(bOOK);
            res.code = "00";
            res.message = "success";
            res.data = bOOKs;
            return res;
        }

        // GET: BOOKs/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: BOOKs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        public ResponseMapper Create(BOOK bOOK)
        {
            var res = new ResponseMapper();
            if (ModelState.IsValid)
            {
                try
                {
                    db.BOOKs.Add(bOOK);
                    db.SaveChanges();
                    res.code = "00";
                    res.message = "success";
                    return res;
                }catch(DBConcurrencyException eb)
                {
                    System.Console.WriteLine();
                    res.code = "06";
                    res.message = eb.GetBaseException().ToString();
                    return res;
                }
            }
            res.code = "06";
            res.message = "not.found";
            return res;
        }

        // GET: BOOKs/Edit/5
      /*  public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
       //     BOOK bOOK = db.BOOKs.Find(id);
       //     if (bOOK == null)
       /////     {
      //          return HttpNotFound();
       //     }
       //     return View(bOOK);
       /// }*/

        // POST: BOOKs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        public ResponseMapper Edit(BOOK bOOK)
        {
            var res = new ResponseMapper();
            if (ModelState.IsValid)
            {
                try
                {
                    db.Entry(bOOK).State = EntityState.Modified;
                    db.SaveChanges();
                    res.code = "00";
                    res.message = "success";
                    return res;
                }catch (DBConcurrencyException eb)
            {
                System.Console.WriteLine();
                    res.code = "06";
                    res.message = eb.GetBaseException().ToString();
                    return res;
            }
        }
            res.code = "06";
            res.message = "edit.failed";
            return res;
        }

        // GET: BOOKs/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BOOK bOOK = db.BOOKs.Find(id);
            if (bOOK == null)
            {
                return HttpNotFound();
            }
            return View(bOOK);
        }

        // POST: BOOKs/Delete/5
        public ResponseMapper DeleteConfirmed(string id)
        {
            var res = new ResponseMapper();
            BOOK bOOK = db.BOOKs.Find(id);
            db.BOOKs.Remove(bOOK);
            db.SaveChanges();
            res.code = "00";
            res.message = "success";
            return res;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
