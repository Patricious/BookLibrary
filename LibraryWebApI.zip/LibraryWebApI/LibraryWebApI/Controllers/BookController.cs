﻿using LibraryWebApI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Http.Cors;

namespace LibraryWebApI.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class BookController : ApiController
    {
        // GET: api/Book
        public ResponseMapper GetAll()
        {
            var result = new BOOKsController().Index();
            return result;
        }

        // GET: api/Book/5
        public ResponseMapper Get([FromUri]string ISBN)
        {
            var book = new BOOKsController().Details(ISBN);
            return book;
        }

        // POST: api/Book
        public ResponseMapper Post([FromBody]BOOK value)
        {
            var result = new BOOKsController().Create(value);
            return result;
        }

        // PUT: api/Book/5
        public ResponseMapper Put([FromBody]BOOK value)
        {
            var result = new BOOKsController().Edit(value);
            return result;
        }

        // DELETE: api/Book/5
        public ResponseMapper Delete([FromBody]BOOK value)
        {
            var result = new BOOKsController().DeleteConfirmed(value.ISBN);
            return result;
        }
    }
}
