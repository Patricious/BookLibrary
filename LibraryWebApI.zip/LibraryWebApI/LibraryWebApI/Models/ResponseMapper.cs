﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LibraryWebApI.Models
{
    public class ResponseMapper
    {
        public string code { set; get; }
        public string message { set; get; }
        public List<BOOK> data {set;get;}
    }
}